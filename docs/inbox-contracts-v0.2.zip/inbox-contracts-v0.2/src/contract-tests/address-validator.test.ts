import { describe, expect, it } from "vitest";
import { AddressStringSchema } from "../enums";

describe("AddressStringSchema", () => {
  // These are real protocol-spec example addresses that previously
  // failed when AddressString was z.string().email().
  // Regression test: keep them passing.
  it("accepts protocol-spec addresses with bare hostnames", () => {
    expect(AddressStringSchema.safeParse("service@vps-1").success).toBe(true);
    expect(AddressStringSchema.safeParse("threat-brief@ops").success).toBe(true);
    expect(AddressStringSchema.safeParse("pm-alpha@vps-1").success).toBe(true);
  });

  it("accepts conventional fixture addresses", () => {
    expect(AddressStringSchema.safeParse("alice@corp.local").success).toBe(true);
    expect(AddressStringSchema.safeParse("eng-leads@lists.local").success).toBe(true);
    expect(AddressStringSchema.safeParse("buildkite@svc.local").success).toBe(true);
  });

  it("accepts addresses with underscores and digits", () => {
    expect(AddressStringSchema.safeParse("agent_1@host").success).toBe(true);
    expect(AddressStringSchema.safeParse("worker-42@cluster-us-east").success).toBe(true);
  });

  it("rejects malformed addresses", () => {
    expect(AddressStringSchema.safeParse("noatsign").success).toBe(false);
    expect(AddressStringSchema.safeParse("@host").success).toBe(false);
    expect(AddressStringSchema.safeParse("user@").success).toBe(false);
    expect(AddressStringSchema.safeParse("user@@host").success).toBe(false);
    expect(AddressStringSchema.safeParse("user with space@host").success).toBe(false);
    expect(AddressStringSchema.safeParse("").success).toBe(false);
  });
});
