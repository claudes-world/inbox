import { z } from "zod";
import { CommandSourceSchema, CommandStatusSchema, EnvironmentRefSchema, PublicErrorCodeSchema, TimestampMsSchema } from "../enums";
import { AddressIdSchema, RunIdSchema, TraceIdSchema } from "../ids";

export const CommandRunSchema = z.object({
  runId: RunIdSchema,
  startedAtMs: TimestampMsSchema,
  completedAtMs: TimestampMsSchema.nullable(),
  actorAddressId: AddressIdSchema.nullable(),
  environment: EnvironmentRefSchema,
  source: CommandSourceSchema,
  commandName: z.string(),
  argsSummary: z.record(z.unknown()),
  status: CommandStatusSchema,
  errorCode: PublicErrorCodeSchema.nullable(),
  affectedEntityIds: z.array(z.string()),
  traceId: TraceIdSchema.nullable(),
});
export type CommandRun = z.infer<typeof CommandRunSchema>;

export const CommandRunListResultSchema = z.object({
  rows: z.array(CommandRunSchema),
  nextCursor: z.string().nullable(),
});
export type CommandRunListResult = z.infer<typeof CommandRunListResultSchema>;
