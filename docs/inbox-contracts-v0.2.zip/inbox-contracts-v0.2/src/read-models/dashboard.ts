import { z } from "zod";
import { TimestampMsSchema } from "../enums";
import { AddressSummarySchema } from "../entities";

export const DashboardSummaryModelSchema = z.object({
  nowMs: TimestampMsSchema,
  windows: z.object({
    last24h: z.object({
      totalMessagesSent: z.number().int().nonnegative(),
      messagesByHuman: z.number().int().nonnegative(),
      messagesByAgent: z.number().int().nonnegative(),
      unreadBacklog: z.number().int().nonnegative(),
      ackNeededBacklog: z.number().int().nonnegative(),
      failedSends: z.number().int().nonnegative(),
      medianTimeToReadMs: z.number().int().nonnegative().nullable(),
      medianTimeToAckMs: z.number().int().nonnegative().nullable(),
    }),
  }),
  activeAgents: z.object({
    active: z.number().int().nonnegative(),
    total: z.number().int().nonnegative(),
  }),
  charts: z.object({
    messageVolume: z.array(z.object({ bucketStartMs: TimestampMsSchema, count: z.number().int().nonnegative() })),
    topCommunicators: z.array(z.object({ address: AddressSummarySchema, messageCount: z.number().int().nonnegative() })),
    threadDepthDistribution: z.array(z.object({ depth: z.number().int().nonnegative(), count: z.number().int().nonnegative() })),
    errorRateByAgent: z.array(z.object({ address: AddressSummarySchema, errorCount: z.number().int().nonnegative() })),
  }),
});
export type DashboardSummaryModel = z.infer<typeof DashboardSummaryModelSchema>;
