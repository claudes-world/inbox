import { z } from "zod";
import { EngagementStateSchema, TimestampMsSchema, UrgencySchema, VisibilityStateSchema } from "../enums";
import { ConversationIdSchema, MessageIdSchema } from "../ids";
import { AddressSummarySchema, ParentLinkDisplaySchema, VisibilityAnnotationSchema } from "../entities";

export const ThreadNodeSchema = VisibilityAnnotationSchema.extend({
  messageId: MessageIdSchema,
  conversationId: ConversationIdSchema,
  parentMessageId: MessageIdSchema.nullable(),
  sender: AddressSummarySchema,
  subject: z.string(),
  bodyPreview: z.string(),
  urgency: UrgencySchema,
  createdAtMs: TimestampMsSchema,
  engagementState: EngagementStateSchema.nullable().optional(),
  visibilityState: VisibilityStateSchema.nullable().optional(),
  parent: ParentLinkDisplaySchema,
  depth: z.number().int().nonnegative(),
  childCount: z.number().int().nonnegative(),
});
export type ThreadNode = z.infer<typeof ThreadNodeSchema>;
