import { z } from "zod";
import { TimestampMsSchema } from "../enums";
import { ConversationIdSchema, MessageIdSchema } from "../ids";
import { AddressSummarySchema, VisibilityMatrixCellSchema } from "../entities";
import { ThreadNodeSchema } from "./thread";

export const VisibilityMatrixRowSchema = z.object({
  messageId: MessageIdSchema,
  cells: z.array(VisibilityMatrixCellSchema),
});
export type VisibilityMatrixRow = z.infer<typeof VisibilityMatrixRowSchema>;

export const ParticipantTimelineEntrySchema = z.object({
  address: AddressSummarySchema,
  firstSeenAtMs: TimestampMsSchema,
});
export type ParticipantTimelineEntry = z.infer<typeof ParticipantTimelineEntrySchema>;

export const DerivedAnomalySchema = z.object({
  code: z.enum([
    "zero_reads_after_threshold",
    "ack_without_prior_read",
    "hidden_immediately_after_delivery",
    "reply_all_audience_changed",
    "direct_list_overlap",
  ]),
  severity: z.enum(["info", "warning", "error"]),
  message: z.string(),
  relatedMessageIds: z.array(MessageIdSchema).optional(),
});
export type DerivedAnomaly = z.infer<typeof DerivedAnomalySchema>;

export const ConversationInspectorModelSchema = z.object({
  conversationId: ConversationIdSchema,
  summary: z.object({
    subjectRoot: z.string().nullable(),
    messageCount: z.number().int().nonnegative(),
    participantCount: z.number().int().nonnegative(),
    firstMessageAtMs: TimestampMsSchema,
    lastMessageAtMs: TimestampMsSchema,
  }),
  // Flat array sorted by createdAtMs ASC. UI builds the tree from parentMessageId references.
  tree: z.array(ThreadNodeSchema),
  visibilityMatrix: z.array(VisibilityMatrixRowSchema),
  participantTimeline: z.array(ParticipantTimelineEntrySchema),
  anomalies: z.array(DerivedAnomalySchema),
});
export type ConversationInspectorModel = z.infer<typeof ConversationInspectorModelSchema>;
