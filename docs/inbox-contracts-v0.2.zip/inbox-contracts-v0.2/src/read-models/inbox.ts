import { z } from "zod";
import { QueryContextSchema } from "../contexts";
import { AddressKindSchema, EngagementStateSchema, TimestampMsSchema, VisibilityStateSchema } from "../enums";
import { AddressIdSchema, ConversationIdSchema, DeliveryIdSchema, MessageIdSchema } from "../ids";
import { AddressSummarySchema, VisibilityAnnotationSchema } from "../entities";

export const InboxFolderSchema = z.enum(["inbox", "sent", "unread", "ack_needed", "hidden", "all"]);
export type InboxFolder = z.infer<typeof InboxFolderSchema>;

export const TimeWindowSchema = z.object({
  fromMs: TimestampMsSchema,
  toMs: TimestampMsSchema,
});
export type TimeWindow = z.infer<typeof TimeWindowSchema>;

export const InboxListRequestSchema = z.object({
  context: QueryContextSchema,
  filter: z.object({
    folder: InboxFolderSchema.optional(),
    state: z.union([EngagementStateSchema, z.literal("any")]).optional(),
    visibility: z.union([VisibilityStateSchema, z.literal("all")]).optional(),
    senderAddressId: AddressIdSchema.optional(),
    senderKinds: z.array(AddressKindSchema).optional(),
    timeWindow: TimeWindowSchema.optional(),
    sort: z.object({
      field: z.enum(["deliveredAtMs", "sender", "urgency", "engagementState"]),
      direction: z.enum(["asc", "desc"]),
    }).optional(),
  }),
  page: z.object({
    limit: z.number().int().positive(),
    cursor: z.string().optional(),
  }).optional(),
});
export type InboxListRequest = z.infer<typeof InboxListRequestSchema>;

export const InboxRowSchema = VisibilityAnnotationSchema.extend({
  deliveryId: DeliveryIdSchema.optional(),
  messageId: MessageIdSchema,
  conversationId: ConversationIdSchema,
  sender: AddressSummarySchema,
  subject: z.string(),
  previewText: z.string(),
  deliveredAtMs: TimestampMsSchema,
  engagementState: EngagementStateSchema,
  visibilityState: VisibilityStateSchema,
  effectiveRole: z.enum(["to", "cc"]),
  participantCount: z.number().int().nonnegative(),
  badgeFlags: z.object({
    urgent: z.boolean(),
    hasReferences: z.boolean(),
    listDelivered: z.boolean(),
    threaded: z.boolean(),
  }),
});
export type InboxRow = z.infer<typeof InboxRowSchema>;

export const InboxListResultSchema = z.object({
  rows: z.array(InboxRowSchema),
  nextCursor: z.string().nullable(),
  totalApprox: z.number().int().nonnegative().optional(),
});
export type InboxListResult = z.infer<typeof InboxListResultSchema>;
