import { z } from "zod";
import { TimestampMsSchema, UrgencySchema, ViewKindSchema, EngagementStateSchema, VisibilityStateSchema } from "../enums";
import { ConversationIdSchema, DeliveryIdSchema, MessageIdSchema } from "../ids";
import {
  AddressSummarySchema,
  DeliverySourceDisplaySchema,
  DeliveryTimelineEventSchema,
  ParentLinkDisplaySchema,
  PublicRecipientDisplaySchema,
  ReferenceDisplaySchema,
  VisibilityAnnotationSchema,
} from "../entities";
import { ThreadNodeSchema } from "./thread";

export const MessageReaderModelSchema = VisibilityAnnotationSchema.extend({
  messageId: MessageIdSchema,
  conversationId: ConversationIdSchema,
  viewKind: ViewKindSchema,
  sender: AddressSummarySchema,
  publicRecipients: z.array(PublicRecipientDisplaySchema),
  subject: z.string(),
  body: z.object({
    format: z.literal("plain"),
    text: z.string(),
  }),
  urgency: UrgencySchema,
  createdAtMs: TimestampMsSchema,
  currentDelivery: VisibilityAnnotationSchema.extend({
    deliveryId: DeliveryIdSchema.optional(),
    engagementState: EngagementStateSchema,
    visibilityState: VisibilityStateSchema,
    effectiveRole: z.enum(["to", "cc"]),
    sourceBreakdown: z.array(DeliverySourceDisplaySchema),
    timeline: z.array(DeliveryTimelineEventSchema),
  }).optional(),
  references: z.array(ReferenceDisplaySchema),
  parent: ParentLinkDisplaySchema,
  threadPreview: z.object({
    mode: z.enum(["chronological", "tree"]),
    nodes: z.array(ThreadNodeSchema),
  }),
  actions: z.object({
    canReply: z.boolean(),
    canReplyAll: z.boolean(),
    canAck: z.boolean(),
    canHide: z.boolean(),
    canUnhide: z.boolean(),
    canPeek: z.boolean(),
  }),
});
export type MessageReaderModel = z.infer<typeof MessageReaderModelSchema>;
