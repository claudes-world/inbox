import { z } from "zod";
import { QueryContextSchema } from "../contexts";
import { AddressKindSchema, PublicErrorCodeSchema, Ratio01Schema, TimestampMsSchema } from "../enums";
import { ConversationIdSchema, MessageIdSchema } from "../ids";
import { AddressSummarySchema } from "../entities";

export const AgentDirectoryRowSchema = z.object({
  address: AddressSummarySchema,
  inboxVolume: z.number().int().nonnegative(),
  sentVolume: z.number().int().nonnegative(),
  avgTimeToReadMs: z.number().int().nonnegative().nullable(),
  ackRate: Ratio01Schema.nullable(),
  lastActiveAtMs: TimestampMsSchema.nullable(),
  createdAtMs: TimestampMsSchema,
});
export type AgentDirectoryRow = z.infer<typeof AgentDirectoryRowSchema>;

export const AgentDirectoryRequestSchema = z.object({
  context: QueryContextSchema,
  filter: z.object({
    kinds: z.array(AddressKindSchema).optional(),
    isActive: z.boolean().optional(),
    isListed: z.boolean().optional(),
    classification: z.string().optional(),
    search: z.string().optional(),
  }).optional(),
  page: z.object({
    limit: z.number().int().positive(),
    cursor: z.string().optional(),
  }).optional(),
});
export type AgentDirectoryRequest = z.infer<typeof AgentDirectoryRequestSchema>;

export const AgentDirectoryResultSchema = z.object({
  rows: z.array(AgentDirectoryRowSchema),
  nextCursor: z.string().nullable(),
});
export type AgentDirectoryResult = z.infer<typeof AgentDirectoryResultSchema>;

export const GroupMemberDisplaySchema = z.object({
  ordinal: z.number().int().nonnegative(),
  member: AddressSummarySchema,
});
export type GroupMemberDisplay = z.infer<typeof GroupMemberDisplaySchema>;

export const AgentProfileModelSchema = z.object({
  address: AddressSummarySchema.extend({
    description: z.string().nullable(),
    createdAtMs: TimestampMsSchema,
    lastActiveAtMs: TimestampMsSchema.nullable(),
  }),
  membership: z.object({
    members: z.array(GroupMemberDisplaySchema),
    zeroActiveMembersWarning: z.boolean(),
  }).optional(),
  communicationSummary: z.object({
    inboundTopPeers: z.array(z.object({ peer: AddressSummarySchema, messageCount: z.number().int().nonnegative() })),
    outboundTopPeers: z.array(z.object({ peer: AddressSummarySchema, messageCount: z.number().int().nonnegative() })),
    messagesOverTime: z.array(z.object({ bucketStartMs: TimestampMsSchema, sent: z.number().int().nonnegative(), received: z.number().int().nonnegative() })),
    avgResponseLatencyMs: z.number().int().nonnegative().nullable(),
    ackRate: Ratio01Schema.nullable(),
  }),
  recentActivity: z.object({
    recentConversationIds: z.array(ConversationIdSchema),
    recentSentMessageIds: z.array(MessageIdSchema),
    recentErrors: z.array(z.object({
      atMs: TimestampMsSchema,
      code: PublicErrorCodeSchema,
      message: z.string(),
    })),
  }),
  actions: z.object({
    canEditProfile: z.boolean(),
    canEditMembership: z.boolean(),
    canDeactivate: z.boolean(),
    canClone: z.boolean(),
    canSendTestMessage: z.boolean(),
  }),
});
export type AgentProfileModel = z.infer<typeof AgentProfileModelSchema>;
