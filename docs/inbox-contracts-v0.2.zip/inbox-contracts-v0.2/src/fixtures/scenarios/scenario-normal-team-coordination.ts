export const scenarioNormalTeamCanonical = {
  scenarioId: "scenario-01-normal-team-coordination",
  addresses: [
    { addressId: "adr_000001", address: "alice@corp.local", kind: "human" },
    { addressId: "adr_000002", address: "bob@corp.local", kind: "human" },
    { addressId: "adr_000010", address: "pm-bot@agents.local", kind: "agent" },
    { addressId: "adr_000020", address: "eng-leads@lists.local", kind: "list" },
  ],
  groupMembers: [
    { groupAddressId: "adr_000020", memberAddressId: "adr_000001", ordinal: 0 },
    { groupAddressId: "adr_000020", memberAddressId: "adr_000002", ordinal: 1 },
  ],
  messages: [
    { messageId: "msg_000001", conversationId: "cnv_000001", senderAddressId: "adr_000010", createdAtMs: 1712740800000 },
    { messageId: "msg_000002", conversationId: "cnv_000001", senderAddressId: "adr_000001", parentMessageId: "msg_000001", createdAtMs: 1712741400000 },
  ],
  deliveries: [
    { deliveryId: "dlv_000101", messageId: "msg_000001", recipientAddressId: "adr_000001", effectiveRole: "to" },
    { deliveryId: "dlv_000102", messageId: "msg_000001", recipientAddressId: "adr_000002", effectiveRole: "to" },
    { deliveryId: "dlv_000201", messageId: "msg_000002", recipientAddressId: "adr_000010", effectiveRole: "to" },
  ],
  deliveryEvents: [
    { eventId: "evt_000001", deliveryId: "dlv_000101", kind: "delivered", atMs: 1712740800000 },
    { eventId: "evt_000002", deliveryId: "dlv_000101", kind: "read", atMs: 1712740980000, actorAddressId: "adr_000001" },
  ],
} as const;
