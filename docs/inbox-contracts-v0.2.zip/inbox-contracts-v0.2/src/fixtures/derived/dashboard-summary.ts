import type { BffSuccess } from "../../envelopes";
import type { DashboardSummaryModel } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const dashboardSummaryFixture: BffSuccess<DashboardSummaryModel> = {
  ok: true,
  result: {
    nowMs: 1712743200000,
    windows: {
      last24h: {
        totalMessagesSent: 38,
        messagesByHuman: 14,
        messagesByAgent: 24,
        unreadBacklog: 5,
        ackNeededBacklog: 3,
        failedSends: 2,
        medianTimeToReadMs: 180000,
        medianTimeToAckMs: 540000,
      },
    },
    activeAgents: {
      active: 2,
      total: 2,
    },
    charts: {
      messageVolume: [
        { bucketStartMs: 1712736000000, count: 8 },
        { bucketStartMs: 1712739600000, count: 12 },
        { bucketStartMs: 1712743200000, count: 18 },
      ],
      topCommunicators: [
        { address: addresses.pmBot, messageCount: 21 },
        { address: addresses.alice, messageCount: 12 },
      ],
      threadDepthDistribution: [
        { depth: 1, count: 10 },
        { depth: 2, count: 4 },
        { depth: 3, count: 1 },
      ],
      errorRateByAgent: [
        { address: addresses.pmBot, errorCount: 1 },
        { address: addresses.triageBot, errorCount: 2 },
      ],
    },
  },
  meta: baseMeta({ mode: "god" }),
};
