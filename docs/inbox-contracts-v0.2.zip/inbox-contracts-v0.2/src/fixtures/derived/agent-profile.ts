import type { BffSuccess } from "../../envelopes";
import type { AgentProfileModel } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const agentProfileListFixture: BffSuccess<AgentProfileModel> = {
  ok: true,
  result: {
    address: {
      ...addresses.engLeads,
      description: "Ordered list for engineering leads and delegated review agents.",
      createdAtMs: 1712484000000,
      lastActiveAtMs: 1712740800000,
    },
    membership: {
      members: [
        { ordinal: 0, member: addresses.alice },
        { ordinal: 1, member: addresses.bob },
        { ordinal: 2, member: addresses.carol },
      ],
      zeroActiveMembersWarning: false,
    },
    communicationSummary: {
      inboundTopPeers: [
        { peer: addresses.pmBot, messageCount: 8 },
      ],
      outboundTopPeers: [],
      messagesOverTime: [
        { bucketStartMs: 1712739600000, sent: 0, received: 2 },
        { bucketStartMs: 1712741400000, sent: 0, received: 1 },
      ],
      avgResponseLatencyMs: 360000,
      ackRate: 0.67,
    },
    recentActivity: {
      recentConversationIds: ["cnv_000001", "cnv_000002"],
      recentSentMessageIds: [],
      recentErrors: [
        {
          atMs: 1712736000000,
          code: "invalid_argument",
          message: "Attempted nested list membership update was rejected.",
        },
      ],
    },
    actions: {
      canEditProfile: true,
      canEditMembership: true,
      canDeactivate: true,
      canClone: true,
      canSendTestMessage: true,
    },
  },
  meta: baseMeta({ mode: "god" }),
};

// Non-list agent profile. Demonstrates the path where `membership`
// is omitted entirely and `canEditMembership` is false.
// Use this fixture for the agent profile screen's non-list path.
export const agentProfilePmBotFixture: BffSuccess<AgentProfileModel> = {
  ok: true,
  result: {
    address: {
      ...addresses.pmBot,
      description: "Planner agent that decomposes incoming briefs and routes work to worker agents.",
      createdAtMs: 1712570400000,
      lastActiveAtMs: 1712742600000,
    },
    communicationSummary: {
      inboundTopPeers: [
        { peer: addresses.alice, messageCount: 6 },
        { peer: addresses.triageBot, messageCount: 4 },
      ],
      outboundTopPeers: [
        { peer: addresses.engLeads, messageCount: 12 },
        { peer: addresses.alice, messageCount: 5 },
        { peer: addresses.triageBot, messageCount: 4 },
      ],
      messagesOverTime: [
        { bucketStartMs: 1712736000000, sent: 5, received: 1 },
        { bucketStartMs: 1712739600000, sent: 8, received: 2 },
        { bucketStartMs: 1712743200000, sent: 8, received: 1 },
      ],
      avgResponseLatencyMs: 120000,
      ackRate: 0.88,
    },
    recentActivity: {
      recentConversationIds: ["cnv_000001", "cnv_000002", "cnv_000003"],
      recentSentMessageIds: ["msg_000001", "msg_000004", "msg_000007"],
      recentErrors: [
        {
          atMs: 1712738400000,
          code: "invalid_state",
          message: "Send rejected: zero recipients resolved after dedupe.",
        },
      ],
    },
    actions: {
      canEditProfile: true,
      canEditMembership: false,
      canDeactivate: true,
      canClone: true,
      canSendTestMessage: true,
    },
  },
  meta: baseMeta({ mode: "god" }),
};
