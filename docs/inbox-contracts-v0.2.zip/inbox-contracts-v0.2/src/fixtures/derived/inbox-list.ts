import type { BffSuccess } from "../../envelopes";
import type { InboxListResult } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const inboxListHappyFixture: BffSuccess<InboxListResult> = {
  ok: true,
  result: {
    rows: [
      {
        deliveryId: "dlv_000101",
        messageId: "msg_000001",
        conversationId: "cnv_000001",
        sender: addresses.pmBot,
        subject: "Need ack: replay panel copy update",
        previewText: "Please ack once the wording change is live in staging.",
        deliveredAtMs: 1712740800000,
        engagementState: "unread",
        visibilityState: "active",
        effectiveRole: "to",
        participantCount: 4,
        isVisibleToHighlightedActor: true,
        badgeFlags: {
          urgent: true,
          hasReferences: true,
          listDelivered: true,
          threaded: true,
        },
      },
      {
        deliveryId: "dlv_000102",
        messageId: "msg_000004",
        conversationId: "cnv_000002",
        sender: addresses.buildkite,
        subject: "Daily digest: sandbox scenario failures",
        previewText: "Two scenario packs failed schema validation after the latest change.",
        deliveredAtMs: 1712737200000,
        engagementState: "acknowledged",
        visibilityState: "hidden",
        effectiveRole: "cc",
        isVisibleToHighlightedActor: true,
        participantCount: 2,
        badgeFlags: {
          urgent: false,
          hasReferences: false,
          listDelivered: false,
          threaded: false,
        },
      },
      {
        deliveryId: "dlv_000103",
        messageId: "msg_000003",
        conversationId: "cnv_000001",
        sender: addresses.triageBot,
        subject: "Re: Need ack: replay panel copy update",
        previewText: "I summarized the requested copy updates and attached the diff.",
        deliveredAtMs: 1712742000000,
        engagementState: "read",
        visibilityState: "active",
        effectiveRole: "to",
        isVisibleToHighlightedActor: false,
        participantCount: 3,
        badgeFlags: {
          urgent: false,
          hasReferences: true,
          listDelivered: false,
          threaded: true,
        },
      },
    ],
    nextCursor: null,
    totalApprox: 3,
  },
  meta: baseMeta({ mode: "god", highlightAddressId: "adr_000001" }),
};

export const inboxListEmptyFixture: BffSuccess<InboxListResult> = {
  ok: true,
  result: {
    rows: [],
    nextCursor: null,
    totalApprox: 0,
  },
  meta: baseMeta({ mode: "god", highlightAddressId: "adr_000001" }),
};
