import type { BffSuccess } from "../../envelopes";
import type { ConversationInspectorModel } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const conversationInspectorFixture: BffSuccess<ConversationInspectorModel> = {
  ok: true,
  result: {
    conversationId: "cnv_000001",
    summary: {
      subjectRoot: "Need ack: replay panel copy update",
      messageCount: 3,
      participantCount: 4,
      firstMessageAtMs: 1712740800000,
      lastMessageAtMs: 1712742000000,
    },
    tree: [
      {
        messageId: "msg_000001",
        conversationId: "cnv_000001",
        parentMessageId: null,
        sender: addresses.pmBot,
        subject: "Need ack: replay panel copy update",
        bodyPreview: "Please ack once the wording change is live in staging.",
        urgency: "urgent",
        createdAtMs: 1712740800000,
        parent: { state: "none" },
        depth: 0,
        childCount: 2,
        isVisibleToHighlightedActor: true,
      },
      {
        messageId: "msg_000002",
        conversationId: "cnv_000001",
        parentMessageId: "msg_000001",
        sender: addresses.alice,
        subject: "Re: Need ack: replay panel copy update",
        bodyPreview: "Ack. I’ll land the wording change after lunch.",
        urgency: "normal",
        createdAtMs: 1712741400000,
        parent: { state: "visible", messageId: "msg_000001", subject: "Need ack: replay panel copy update" },
        depth: 1,
        childCount: 0,
        isVisibleToHighlightedActor: true,
      },
      {
        messageId: "msg_000003",
        conversationId: "cnv_000001",
        parentMessageId: "msg_000001",
        sender: addresses.triageBot,
        subject: "Re: Need ack: replay panel copy update",
        bodyPreview: "I summarized the requested copy updates and attached the diff.",
        urgency: "normal",
        createdAtMs: 1712742000000,
        parent: { state: "visible", messageId: "msg_000001", subject: "Need ack: replay panel copy update" },
        depth: 1,
        childCount: 0,
        isVisibleToHighlightedActor: false,
      },
    ],
    visibilityMatrix: [
      {
        messageId: "msg_000001",
        cells: [
          { addressId: addresses.alice.addressId, delivery: { engagement: "unread", visibility: "active" }, isVisibleToHighlightedActor: true },
          { addressId: addresses.bob.addressId, delivery: { engagement: "read", visibility: "active" }, isVisibleToHighlightedActor: false },
          { addressId: addresses.carol.addressId, delivery: null, isVisibleToHighlightedActor: false },
          { addressId: addresses.pmBot.addressId, delivery: null, isVisibleToHighlightedActor: false },
        ],
      },
      {
        messageId: "msg_000002",
        cells: [
          { addressId: addresses.pmBot.addressId, delivery: { engagement: "read", visibility: "active" }, isVisibleToHighlightedActor: false },
          { addressId: addresses.alice.addressId, delivery: null, isVisibleToHighlightedActor: true },
        ],
      },
      {
        messageId: "msg_000004",
        cells: [
          { addressId: addresses.alice.addressId, delivery: { engagement: "acknowledged", visibility: "hidden" }, isVisibleToHighlightedActor: true },
        ],
      },
    ],
    participantTimeline: [
      { address: addresses.pmBot, firstSeenAtMs: 1712740800000 },
      { address: addresses.alice, firstSeenAtMs: 1712740800000 },
      { address: addresses.bob, firstSeenAtMs: 1712740800000 },
      { address: addresses.triageBot, firstSeenAtMs: 1712742000000 },
    ],
    anomalies: [
      {
        code: "direct_list_overlap",
        severity: "info",
        message: "Alice was reached through both a direct cc and eng-leads list expansion on msg_000001.",
        relatedMessageIds: ["msg_000001"],
      },
      {
        code: "hidden_immediately_after_delivery",
        severity: "warning",
        message: "A delivery in this conversation was hidden within one minute of delivery.",
        relatedMessageIds: ["msg_000004"],
      },
    ],
  },
  meta: baseMeta({ mode: "god", highlightAddressId: "adr_000001" }),
};
