import type { BffMeta } from "../../envelopes";

export const baseMeta = (scope?: BffMeta["scope"]): BffMeta => ({
  env: "local",
  scope,
  asOfMs: 1712743200000,
  requestId: "req_fixture_0001",
});
