import type { BffSuccess } from "../../envelopes";
import type { ComposeDryRunResult, SendMessageResult } from "../../actions";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const composeDryRunHappyFixture: BffSuccess<ComposeDryRunResult> = {
  ok: true,
  result: {
    validation: {
      senderIsActive: true,
      hasAtLeastOneTo: true,
      bodyPresent: true,
      allLogicalRecipientsKnown: true,
      resolvesToAtLeastOneActualRecipient: true,
      ok: true,
    },
    logicalRecipients: [
      { inputOrdinal: 0, role: "to", address: addresses.engLeads.address, addressId: addresses.engLeads.addressId, status: "known" },
      { inputOrdinal: 1, role: "cc", address: addresses.alice.address, addressId: addresses.alice.addressId, status: "known" },
    ],
    expansion: [
      {
        logicalRecipientOrdinal: 0,
        logicalAddress: addresses.engLeads.address,
        logicalRole: "to",
        expandedAddressId: addresses.alice.addressId,
        expandedAddress: addresses.alice.address,
        expandedVia: { kind: "list", listAddressId: addresses.engLeads.addressId, listAddress: addresses.engLeads.address, memberOrdinal: 0 },
        recipientStatus: "active",
      },
      {
        logicalRecipientOrdinal: 0,
        logicalAddress: addresses.engLeads.address,
        logicalRole: "to",
        expandedAddressId: addresses.bob.addressId,
        expandedAddress: addresses.bob.address,
        expandedVia: { kind: "list", listAddressId: addresses.engLeads.addressId, listAddress: addresses.engLeads.address, memberOrdinal: 1 },
        recipientStatus: "active",
      },
      {
        logicalRecipientOrdinal: 0,
        logicalAddress: addresses.engLeads.address,
        logicalRole: "to",
        expandedAddressId: addresses.carol.addressId,
        expandedAddress: addresses.carol.address,
        expandedVia: { kind: "list", listAddressId: addresses.engLeads.addressId, listAddress: addresses.engLeads.address, memberOrdinal: 2 },
        recipientStatus: "inactive",
      },
      {
        logicalRecipientOrdinal: 1,
        logicalAddress: addresses.alice.address,
        logicalRole: "cc",
        expandedAddressId: addresses.alice.addressId,
        expandedAddress: addresses.alice.address,
        expandedVia: { kind: "direct" },
        recipientStatus: "active",
      },
    ],
    resolvedRecipients: [
      {
        addressId: addresses.alice.addressId,
        address: addresses.alice.address,
        effectiveRole: "to",
        sourceBreakdown: [
          { kind: "list", role: "to", listAddressId: addresses.engLeads.addressId, listAddress: addresses.engLeads.address },
          { kind: "direct", role: "cc" },
        ],
        included: true,
      },
      {
        addressId: addresses.bob.addressId,
        address: addresses.bob.address,
        effectiveRole: "to",
        sourceBreakdown: [
          { kind: "list", role: "to", listAddressId: addresses.engLeads.addressId, listAddress: addresses.engLeads.address },
        ],
        included: true,
      },
      {
        addressId: addresses.carol.addressId,
        address: addresses.carol.address,
        effectiveRole: "to",
        sourceBreakdown: [
          { kind: "list", role: "to", listAddressId: addresses.engLeads.addressId, listAddress: addresses.engLeads.address },
        ],
        included: false,
        exclusionReason: "inactive",
      },
    ],
    warnings: [
      {
        code: "inactive_recipient",
        message: "carol@corp.local is inactive and will not receive a delivery.",
      },
      {
        code: "cross_role_overlap_preserved",
        message: "alice@corp.local is reached directly and via list expansion; highest-precedence effective role will be used.",
      },
    ],
    resolutionSummary: {
      logicalRecipientCount: 2,
      resolvedRecipientCount: 2,
      skippedInactiveMemberCount: 1,
      dedupedRecipientCount: 1,
      expandedCandidateCount: 4,
    },
  },
  meta: baseMeta(),
};

export const composeDryRunZeroResolutionFixture: BffSuccess<ComposeDryRunResult> = {
  ok: true,
  result: {
    validation: {
      senderIsActive: false,
      hasAtLeastOneTo: true,
      bodyPresent: true,
      allLogicalRecipientsKnown: true,
      resolvesToAtLeastOneActualRecipient: false,
      ok: false,
    },
    logicalRecipients: [
      { inputOrdinal: 0, role: "to", address: addresses.carol.address, addressId: addresses.carol.addressId, status: "inactive" },
    ],
    expansion: [
      {
        logicalRecipientOrdinal: 0,
        logicalAddress: addresses.carol.address,
        logicalRole: "to",
        expandedAddressId: addresses.carol.addressId,
        expandedAddress: addresses.carol.address,
        expandedVia: { kind: "direct" },
        recipientStatus: "inactive",
      },
    ],
    resolvedRecipients: [
      {
        addressId: addresses.carol.addressId,
        address: addresses.carol.address,
        effectiveRole: "to",
        sourceBreakdown: [
          { kind: "direct", role: "to" },
        ],
        included: false,
        exclusionReason: "inactive",
      },
    ],
    warnings: [
      {
        code: "inactive_acting_address",
        message: "The selected sender is inactive and cannot send.",
      },
      {
        code: "inactive_recipient",
        message: "carol@corp.local is inactive and will not receive a delivery.",
      },
      {
        code: "zero_resolution",
        message: "No active recipients remain after resolution.",
      },
    ],
    resolutionSummary: {
      logicalRecipientCount: 1,
      resolvedRecipientCount: 0,
      skippedInactiveMemberCount: 1,
      dedupedRecipientCount: 0,
      expandedCandidateCount: 1,
    },
  },
  meta: baseMeta(),
};

export const sendMessageFixture: BffSuccess<SendMessageResult> = {
  ok: true,
  result: {
    messageId: "msg_000010",
    conversationId: "cnv_000010",
    resolutionSummary: {
      logicalRecipientCount: 2,
      resolvedRecipientCount: 2,
      skippedInactiveMemberCount: 1,
      dedupedRecipientCount: 1,
    },
    publicRecipients: [
      {
        ordinal: 0,
        role: "to",
        addressId: addresses.engLeads.addressId,
        address: addresses.engLeads.address,
        displayName: addresses.engLeads.displayName,
        kind: addresses.engLeads.kind,
      },
      {
        ordinal: 1,
        role: "cc",
        addressId: addresses.alice.addressId,
        address: addresses.alice.address,
        displayName: addresses.alice.displayName,
        kind: addresses.alice.kind,
      },
    ],
  },
  meta: baseMeta(),
};
