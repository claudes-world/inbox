import type { BffSuccess } from "../../envelopes";
import type { AgentDirectoryResult } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const agentDirectoryHappyFixture: BffSuccess<AgentDirectoryResult> = {
  ok: true,
  result: {
    rows: [
      {
        address: addresses.alice,
        inboxVolume: 14,
        sentVolume: 6,
        avgTimeToReadMs: 240000,
        ackRate: 0.71,
        lastActiveAtMs: 1712742000000,
        createdAtMs: 1712656800000,
      },
      {
        address: addresses.pmBot,
        inboxVolume: 4,
        sentVolume: 21,
        avgTimeToReadMs: 120000,
        ackRate: 0.88,
        lastActiveAtMs: 1712742600000,
        createdAtMs: 1712570400000,
      },
      {
        address: addresses.engLeads,
        inboxVolume: 0,
        sentVolume: 0,
        avgTimeToReadMs: null,
        ackRate: null,
        lastActiveAtMs: null,
        createdAtMs: 1712484000000,
      },
    ],
    nextCursor: null,
  },
  meta: baseMeta({ mode: "god" }),
};

export const agentDirectoryEmptyFixture: BffSuccess<AgentDirectoryResult> = {
  ok: true,
  result: {
    rows: [],
    nextCursor: null,
  },
  meta: baseMeta({ mode: "god" }),
};
