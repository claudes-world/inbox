import type { BffSuccess } from "../../envelopes";
import type { CommandRunListResult } from "../../read-models";
import { baseMeta } from "./common";

export const commandRunsFixture: BffSuccess<CommandRunListResult> = {
  ok: true,
  result: {
    rows: [
      {
        runId: "run_000001",
        startedAtMs: 1712740700000,
        completedAtMs: 1712740700800,
        actorAddressId: "adr_000010",
        environment: "local",
        source: "ui",
        commandName: "messages.send",
        argsSummary: {
          senderAddressId: "adr_000010",
          toCount: 1,
          ccCount: 1,
        },
        status: "success",
        errorCode: null,
        affectedEntityIds: ["msg_000001", "cnv_000001"],
        traceId: "trace_local_send_0001",
      },
      {
        runId: "run_000002",
        startedAtMs: 1712741300000,
        completedAtMs: 1712741300300,
        actorAddressId: "adr_000001",
        environment: "local",
        source: "ui",
        commandName: "messages.ack",
        argsSummary: {
          messageId: "msg_000001",
        },
        status: "rejected",
        errorCode: "invalid_state",
        affectedEntityIds: ["msg_000001"],
        traceId: "trace_local_ack_0002",
      },
    ],
    nextCursor: null,
  },
  meta: baseMeta({ mode: "god" }),
};
