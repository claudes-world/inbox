import type { BffSuccess } from "../../envelopes";
import type { SessionModel } from "../../read-models";
import { baseMeta } from "./common";

export const sessionFixture: BffSuccess<SessionModel> = {
  ok: true,
  result: {
    env: "local",
    dbPath: "/tmp/inbox-dev.sqlite",
    defaultViewScope: { mode: "god", highlightAddressId: "adr_000001" },
    defaultSendIdentity: "adr_000010",
    resolvedActingAddressId: "adr_000001",
    asOfMs: 1712743200000,
  },
  meta: baseMeta({ mode: "god", highlightAddressId: "adr_000001" }),
};
