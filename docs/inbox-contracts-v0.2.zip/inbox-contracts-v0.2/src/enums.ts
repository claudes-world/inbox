import { z } from "zod";

export const EnvironmentRefValues = ["local", "dev", "staging", "prod", "experimental"] as const;
export type EnvironmentRef = (typeof EnvironmentRefValues)[number];
export const EnvironmentRefSchema = z.enum(EnvironmentRefValues);

export const AddressKindValues = ["agent", "human", "service", "list"] as const;
export type AddressKind = (typeof AddressKindValues)[number];
export const AddressKindSchema = z.enum(AddressKindValues);

export const UrgencyValues = ["low", "normal", "high", "urgent"] as const;
export type Urgency = (typeof UrgencyValues)[number];
export const UrgencySchema = z.enum(UrgencyValues);

export const EngagementStateValues = ["unread", "read", "acknowledged"] as const;
export type EngagementState = (typeof EngagementStateValues)[number];
export const EngagementStateSchema = z.enum(EngagementStateValues);

export const VisibilityStateValues = ["active", "hidden"] as const;
export type VisibilityState = (typeof VisibilityStateValues)[number];
export const VisibilityStateSchema = z.enum(VisibilityStateValues);

// MVP CLI does not expose bcc, but the protocol schema reserves it.
// EffectiveRole is intentionally limited to "to" | "cc" at the BFF v1 layer.
export const EffectiveRoleValues = ["to", "cc"] as const;
export type EffectiveRole = (typeof EffectiveRoleValues)[number];
export const EffectiveRoleSchema = z.enum(EffectiveRoleValues);

export const ViewKindValues = ["received", "sent"] as const;
export type ViewKind = (typeof ViewKindValues)[number];
export const ViewKindSchema = z.enum(ViewKindValues);

export type Ratio01 = number;
export const Ratio01Schema = z.number().min(0).max(1);

export const CommandSourceValues = ["cli", "ui", "sandbox", "system"] as const;
export type CommandSource = (typeof CommandSourceValues)[number];
export const CommandSourceSchema = z.enum(CommandSourceValues);

export const CommandStatusValues = ["success", "error", "rejected"] as const;
export type CommandStatus = (typeof CommandStatusValues)[number];
export const CommandStatusSchema = z.enum(CommandStatusValues);

export const ProtocolErrorCodeValues = [
  "invalid_argument",
  "invalid_state",
  "not_found",
  "permission_denied",
  "internal_error",
] as const;
export type ProtocolErrorCode = (typeof ProtocolErrorCodeValues)[number];
export const ProtocolErrorCodeSchema = z.enum(ProtocolErrorCodeValues);

export const ExperimentalErrorCodeValues = ["coming_soon"] as const;
export type ExperimentalErrorCode = (typeof ExperimentalErrorCodeValues)[number];
export const ExperimentalErrorCodeSchema = z.enum(ExperimentalErrorCodeValues);

export type PublicErrorCode = ProtocolErrorCode | ExperimentalErrorCode;
export const PublicErrorCodeSchema = z.union([ProtocolErrorCodeSchema, ExperimentalErrorCodeSchema]);

export type TimestampMs = number;
export const TimestampMsSchema = z.number().int().nonnegative();

// Inbox addresses are local_part@host where host is whatever the protocol uses,
// including bare hostnames like "vps-1" or "ops". This is intentionally NOT
// RFC 5322 email validation — that rejects valid protocol addresses such as
// service@vps-1 or threat-brief@ops.
export type AddressString = string;
export const AddressStringSchema = z
  .string()
  .min(3)
  .regex(/^[^@\s]+@[^@\s]+$/, "must be local_part@host");
