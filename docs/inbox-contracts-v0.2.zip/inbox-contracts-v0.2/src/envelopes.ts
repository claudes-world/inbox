import { z } from "zod";
import { ViewScopeSchema } from "./contexts";
import { EnvironmentRefSchema, PublicErrorCodeSchema, TimestampMsSchema } from "./enums";

export const BffMetaSchema = z.object({
  env: EnvironmentRefSchema,
  scope: ViewScopeSchema.optional(),
  asOfMs: TimestampMsSchema.nullable(),
  requestId: z.string().min(1),
});
export type BffMeta = z.infer<typeof BffMetaSchema>;

export const makeBffSuccessSchema = <T extends z.ZodTypeAny>(resultSchema: T) =>
  z.object({
    ok: z.literal(true),
    result: resultSchema,
    meta: BffMetaSchema,
  });

export const BffFailureSchema = z.object({
  ok: z.literal(false),
  error: z.object({
    code: PublicErrorCodeSchema,
    message: z.string(),
    details: z.record(z.unknown()).optional(),
  }),
  meta: BffMetaSchema,
});
export type BffFailure = z.infer<typeof BffFailureSchema>;

export const makeBffResponseSchema = <T extends z.ZodTypeAny>(resultSchema: T) =>
  z.union([makeBffSuccessSchema(resultSchema), BffFailureSchema]);

export type BffSuccess<T> = {
  ok: true;
  result: T;
  meta: BffMeta;
};

export type BffResponse<T> = BffSuccess<T> | BffFailure;
