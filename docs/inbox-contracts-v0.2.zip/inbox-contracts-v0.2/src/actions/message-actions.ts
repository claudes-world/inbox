import { z } from "zod";
import { ActionContextSchema } from "../contexts";
import { ConversationIdSchema, MessageIdSchema } from "../ids";
import { EngagementStateSchema, VisibilityStateSchema } from "../enums";

export const MessageActionRequestSchema = z.object({
  context: ActionContextSchema,
});
export type MessageActionRequest = z.infer<typeof MessageActionRequestSchema>;

export const MessageActionResultSchema = z.object({
  messageId: MessageIdSchema,
  conversationId: ConversationIdSchema,
  resultingEngagementState: EngagementStateSchema.optional(),
  resultingVisibilityState: VisibilityStateSchema.optional(),
  eventRecorded: z.boolean(),
});
export type MessageActionResult = z.infer<typeof MessageActionResultSchema>;
