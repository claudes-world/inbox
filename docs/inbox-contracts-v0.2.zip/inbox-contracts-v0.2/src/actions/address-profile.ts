import { z } from "zod";
import { ActionContextSchema } from "../contexts";
import { TimestampMsSchema } from "../enums";
import { AddressIdSchema } from "../ids";
import { AddressSummarySchema } from "../entities";

export const UpdateAddressProfileRequestSchema = z.object({
  context: ActionContextSchema,
  input: z.object({
    addressId: AddressIdSchema,
    displayName: z.string().nullable(),
    description: z.string().nullable(),
    isActive: z.boolean(),
    isListed: z.boolean(),
    classification: z.string().nullable(),
  }),
});
export type UpdateAddressProfileRequest = z.infer<typeof UpdateAddressProfileRequestSchema>;

export const UpdateAddressProfileResultSchema = z.object({
  address: AddressSummarySchema.extend({
    description: z.string().nullable(),
    updatedAtMs: TimestampMsSchema,
  }),
});
export type UpdateAddressProfileResult = z.infer<typeof UpdateAddressProfileResultSchema>;
