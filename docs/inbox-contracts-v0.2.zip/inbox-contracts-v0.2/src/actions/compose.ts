import { z } from "zod";
import { ActionContextSchema } from "../contexts";
import { AddressStringSchema, EffectiveRoleSchema, UrgencySchema } from "../enums";
import { AddressIdSchema, ConversationIdSchema, MessageIdSchema } from "../ids";
import { DryRunResolutionSummarySchema, PublicRecipientDisplaySchema, ResolutionSummarySchema } from "../entities";

export const ReferenceInputSchema = z.object({
  kind: z.string(),
  value: z.string(),
  label: z.string().nullable().optional(),
  mimeType: z.string().nullable().optional(),
});
export type ReferenceInput = z.infer<typeof ReferenceInputSchema>;

export const ComposeMessageInputSchema = z.object({
  senderAddressId: AddressIdSchema,
  to: z.array(AddressStringSchema),
  cc: z.array(AddressStringSchema),
  subject: z.string(),
  bodyText: z.string(),
  urgency: UrgencySchema,
  references: z.array(ReferenceInputSchema).optional(),
});
export type ComposeMessageInput = z.infer<typeof ComposeMessageInputSchema>;

export const ComposeDryRunRequestSchema = z.object({
  context: ActionContextSchema,
  input: ComposeMessageInputSchema,
});
export type ComposeDryRunRequest = z.infer<typeof ComposeDryRunRequestSchema>;

export const ComposeDryRunResultSchema = z.object({
  validation: z.object({
    senderIsActive: z.boolean(),
    hasAtLeastOneTo: z.boolean(),
    bodyPresent: z.boolean(),
    allLogicalRecipientsKnown: z.boolean(),
    resolvesToAtLeastOneActualRecipient: z.boolean(),
    ok: z.boolean(),
  }),
  logicalRecipients: z.array(z.object({
    inputOrdinal: z.number().int().nonnegative(),
    role: EffectiveRoleSchema,
    address: AddressStringSchema,
    addressId: AddressIdSchema.nullable(),
    status: z.enum(["known", "unknown", "inactive"]),
  })),
  expansion: z.array(z.object({
    logicalRecipientOrdinal: z.number().int().nonnegative(),
    logicalAddress: AddressStringSchema,
    logicalRole: EffectiveRoleSchema,
    expandedAddressId: AddressIdSchema,
    expandedAddress: AddressStringSchema,
    expandedVia: z.discriminatedUnion("kind", [
      z.object({ kind: z.literal("direct") }),
      z.object({
        kind: z.literal("list"),
        listAddressId: AddressIdSchema,
        listAddress: AddressStringSchema,
        memberOrdinal: z.number().int().nonnegative(),
      }),
    ]),
    recipientStatus: z.enum(["active", "inactive"]),
  })),
  resolvedRecipients: z.array(z.object({
    addressId: AddressIdSchema,
    address: AddressStringSchema,
    effectiveRole: EffectiveRoleSchema,
    sourceBreakdown: z.array(z.discriminatedUnion("kind", [
      z.object({ kind: z.literal("direct"), role: EffectiveRoleSchema }),
      z.object({ kind: z.literal("list"), role: EffectiveRoleSchema, listAddressId: AddressIdSchema, listAddress: AddressStringSchema }),
    ])),
    included: z.boolean(),
    exclusionReason: z.enum(["inactive", "deduped_lower_precedence"]).optional(),
  })),
  warnings: z.array(z.object({
    code: z.enum([
      "unknown_recipient",
      "inactive_acting_address",
      "inactive_recipient",
      "inactive_list",
      "all_inactive_list_members",
      "zero_resolution",
      "duplicate_same_role_deduped",
      "cross_role_overlap_preserved",
    ]),
    message: z.string(),
  })),
  resolutionSummary: DryRunResolutionSummarySchema,
});
export type ComposeDryRunResult = z.infer<typeof ComposeDryRunResultSchema>;

export const SendMessageRequestSchema = z.object({
  context: ActionContextSchema,
  input: ComposeMessageInputSchema,
});
export type SendMessageRequest = z.infer<typeof SendMessageRequestSchema>;

export const SendMessageResultSchema = z.object({
  messageId: MessageIdSchema,
  conversationId: ConversationIdSchema,
  resolutionSummary: ResolutionSummarySchema,
  publicRecipients: z.array(PublicRecipientDisplaySchema),
});
export type SendMessageResult = z.infer<typeof SendMessageResultSchema>;
