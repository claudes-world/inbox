import { z } from "zod";
import { ActionContextSchema } from "../contexts";
import { TimestampMsSchema } from "../enums";
import { AddressIdSchema } from "../ids";
import { GroupMemberDisplaySchema } from "../read-models/agents";

export const UpdateGroupMembershipRequestSchema = z.object({
  context: ActionContextSchema,
  input: z.object({
    groupAddressId: AddressIdSchema,
    members: z.array(z.object({
      addressId: AddressIdSchema,
      ordinal: z.number().int().nonnegative(),
    })),
  }),
});
export type UpdateGroupMembershipRequest = z.infer<typeof UpdateGroupMembershipRequestSchema>;

export const UpdateGroupMembershipResultSchema = z.object({
  groupAddressId: AddressIdSchema,
  members: z.array(GroupMemberDisplaySchema),
  updatedAtMs: TimestampMsSchema,
});
export type UpdateGroupMembershipResult = z.infer<typeof UpdateGroupMembershipResultSchema>;
