export type ScenarioMetadata = {
  scenarioId: string;
  title: string;
  description: string;
  qualityGateIds: number[];
  tags: string[];
};

export const scenarioLibrary: ScenarioMetadata[] = [
  {
    scenarioId: "scenario-01-normal-team-coordination",
    title: "Normal team coordination",
    description: "PM bot sends to eng leads, recipients read at different times, and one engineer replies.",
    qualityGateIds: [1, 2, 3],
    tags: ["happy-path", "threading", "ack"],
  },
  {
    scenarioId: "scenario-02-reply-all-membership-change",
    title: "Reply-all with membership change",
    description: "Reply-all audience changes after list membership updates.",
    qualityGateIds: [4, 6],
    tags: ["reply-all", "lists", "audience-evolution"],
  },
  {
    scenarioId: "scenario-10-direct-list-overlap-dedup",
    title: "Direct plus list overlap dedup",
    description: "A recipient is reached through a direct address and a list expansion, producing one actual delivery with multiple sources.",
    qualityGateIds: [11],
    tags: ["dedup", "compose-dry-run", "delivery-sources"],
  },
];
