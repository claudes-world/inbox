import { z } from "zod";
import { AddressIdSchema } from "./ids";
import { EnvironmentRefSchema, TimestampMsSchema } from "./enums";

export const ViewScopeSchema = z.union([
  z.object({
    mode: z.literal("actor"),
    addressId: AddressIdSchema,
  }),
  z.object({
    mode: z.literal("god"),
    highlightAddressId: AddressIdSchema.nullish(),
  }),
]);
export type ViewScope = z.infer<typeof ViewScopeSchema>;

export const QueryContextSchema = z.object({
  env: EnvironmentRefSchema,
  scope: ViewScopeSchema,
  asOfMs: TimestampMsSchema.nullish(),
});
export type QueryContext = z.infer<typeof QueryContextSchema>;

export const ActionContextSchema = z.object({
  env: EnvironmentRefSchema,
  actorAddressId: AddressIdSchema,
  asOfMs: TimestampMsSchema.nullish(),
});
export type ActionContext = z.infer<typeof ActionContextSchema>;
