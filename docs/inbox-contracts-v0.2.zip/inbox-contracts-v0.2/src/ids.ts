import { z } from "zod";

// Inbox addresses for lists are normal addresses with kind='list'.
// There is intentionally no separate GroupId — use AddressId everywhere
// a list reference is needed, and check kind='list' at the service layer.
export type MessageId = string;
export type DeliveryId = string;
export type ConversationId = string;
export type AddressId = string;
export type RunId = string;
export type TraceId = string;
export type EventId = string;

export const MessageIdSchema = z.string().regex(/^msg_[A-Za-z0-9_-]+$/);
export const DeliveryIdSchema = z.string().regex(/^dlv_[A-Za-z0-9_-]+$/);
export const ConversationIdSchema = z.string().regex(/^cnv_[A-Za-z0-9_-]+$/);
export const AddressIdSchema = z.string().regex(/^adr_[A-Za-z0-9_-]+$/);
export const RunIdSchema = z.string().regex(/^run_[A-Za-z0-9_-]+$/);
export const TraceIdSchema = z.string().min(1);
export const EventIdSchema = z.string().regex(/^evt_[A-Za-z0-9_-]+$/);
