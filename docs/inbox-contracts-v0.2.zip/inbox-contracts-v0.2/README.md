# @inbox/contracts

Shared BFF contracts, Zod schemas, and deterministic fixture packs for Inbox dev tooling.

## What is in here

- shared IDs, enums, contexts, and envelopes
- page-shaped read/write models for the first Inbox dev-tooling surfaces
- Zod schemas for every exported contract
- deterministic fixture packs for UI work and contract testing
- scenario metadata with quality-gate traceability

## Usage

```ts
import {
  InboxListResultSchema,
  inboxListHappyFixture,
  type InboxListResult,
} from "@inbox/contracts";

const parsed: InboxListResult = InboxListResultSchema.parse(inboxListHappyFixture.result);
```

## Notes

- The BFF contract layer is intentionally distinct from the frozen CLI/protocol envelope.
- Contracts use Unix milliseconds throughout.
- Public message mutations use `messageId`, not `deliveryId`.
- `bcc` is intentionally excluded from BFF v1 read/write role unions even though the protocol schema reserves it.
