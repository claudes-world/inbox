# Changelog

## 0.2.0

### Fixed

- **Address validation no longer rejects valid protocol addresses.** Replaced every `z.string().email()` with a permissive `AddressStringSchema` (`local_part@host` shape, no TLD requirement). RFC 5322 email validation rejected real addresses from the protocol spec such as `service@vps-1` and `threat-brief@ops`. Affects `entities/shared.ts` and `actions/compose.ts`.
- **`SessionModel.dbPath`** now requires `min(1)` to reject empty strings.

### Removed

- **`GroupId` type and `GroupIdSchema`** were dead code — defined but never imported. Lists are addresses with `kind='list'`, so `AddressId` is the correct type for any list reference. Use `AddressIdSchema` everywhere a list is referenced and check `kind` at the service layer.

### Added

- **`AddressStringSchema`** exported from `enums.ts` for any address-string field.
- **`AddressString`** type alias for the same.
- **`messageReaderEngagedFixture`** — demonstrates the full delivery lifecycle with `read` and `ack` events carrying non-null `actorAddressId`, as required by the protocol invariant. Use for designing the event timeline strip and any UI that renders engagement state transitions.
- **`agentProfilePmBotFixture`** — non-list agent profile where `membership` is omitted and `canEditMembership` is false. Use for the agent profile screen's non-list path.
- **Regression test suite** for `AddressStringSchema` covering protocol-spec addresses, fixture addresses, addresses with underscores/digits, and malformed inputs.

### Migration notes

If a downstream consumer was importing `GroupId` or `GroupIdSchema` from `@inbox/contracts`, replace with `AddressId` and `AddressIdSchema`. There were no internal usages, so this should be a no-op for any consumer that followed the brief.

## 0.1.0

Initial contracts package skeleton.
