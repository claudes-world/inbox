import type { BffSuccess } from "../../envelopes";
import type { AgentProfileModel } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const agentProfileListFixture: BffSuccess<AgentProfileModel> = {
  ok: true,
  result: {
    address: {
      ...addresses.engLeads,
      description: "Ordered list for engineering leads and delegated review agents.",
      createdAtMs: 1712484000000,
      lastActiveAtMs: 1712740800000,
    },
    membership: {
      members: [
        { ordinal: 0, member: addresses.alice },
        { ordinal: 1, member: addresses.bob },
        { ordinal: 2, member: addresses.carol },
      ],
      zeroActiveMembersWarning: false,
    },
    communicationSummary: {
      inboundTopPeers: [
        { peer: addresses.pmBot, messageCount: 8 },
      ],
      outboundTopPeers: [],
      messagesOverTime: [
        { bucketStartMs: 1712739600000, sent: 0, received: 2 },
        { bucketStartMs: 1712741400000, sent: 0, received: 1 },
      ],
      avgResponseLatencyMs: 360000,
      ackRate: 0.67,
    },
    recentActivity: {
      recentConversationIds: ["cnv_000001", "cnv_000002"],
      recentSentMessageIds: [],
      recentErrors: [
        {
          atMs: 1712736000000,
          code: "invalid_argument",
          message: "Attempted nested list membership update was rejected.",
        },
      ],
    },
    actions: {
      canEditProfile: true,
      canEditMembership: true,
      canDeactivate: true,
      canClone: true,
      canSendTestMessage: true,
    },
  },
  meta: baseMeta({ mode: "god" }),
};
