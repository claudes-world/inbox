import type { BffSuccess } from "../../envelopes";
import type { MessageReaderModel } from "../../read-models";
import { addresses } from "./addresses";
import { baseMeta } from "./common";

export const messageReaderHappyFixture: BffSuccess<MessageReaderModel> = {
  ok: true,
  result: {
    messageId: "msg_000001",
    conversationId: "cnv_000001",
    viewKind: "received",
    sender: addresses.pmBot,
    isVisibleToHighlightedActor: true,
    publicRecipients: [
      {
        ordinal: 0,
        role: "to",
        addressId: addresses.engLeads.addressId,
        address: addresses.engLeads.address,
        displayName: addresses.engLeads.displayName,
        kind: addresses.engLeads.kind,
        isVisibleToHighlightedActor: true,
      },
      {
        ordinal: 1,
        role: "cc",
        addressId: addresses.alice.addressId,
        address: addresses.alice.address,
        displayName: addresses.alice.displayName,
        kind: addresses.alice.kind,
        isVisibleToHighlightedActor: true,
      },
    ],
    subject: "Need ack: replay panel copy update",
    body: {
      format: "plain",
      text: "Please ack once the wording change is live in staging. I attached the final copy path and the PR reference.",
    },
    urgency: "urgent",
    createdAtMs: 1712740800000,
    currentDelivery: {
      deliveryId: "dlv_000101",
      engagementState: "unread",
      visibilityState: "active",
      effectiveRole: "to",
      isVisibleToHighlightedActor: true,
      sourceBreakdown: [
        {
          kind: "direct",
          role: "cc",
        },
        {
          kind: "list",
          role: "to",
          listAddressId: addresses.engLeads.addressId,
          listAddress: addresses.engLeads.address,
        },
      ],
      timeline: [
        {
          kind: "delivered",
          atMs: 1712740800000,
          actorAddressId: null,
        },
      ],
    },
    references: [
      {
        kind: "path",
        value: "/repo/ui/src/copy/replay-panel.ts",
        label: "Replay panel copy file",
      },
      {
        kind: "url",
        value: "https://example.local/pr/42",
        label: "PR 42",
      },
    ],
    parent: {
      state: "none",
    },
    threadPreview: {
      mode: "tree",
      nodes: [
        {
          messageId: "msg_000001",
          conversationId: "cnv_000001",
          parentMessageId: null,
          sender: addresses.pmBot,
          subject: "Need ack: replay panel copy update",
          bodyPreview: "Please ack once the wording change is live in staging.",
          urgency: "urgent",
          createdAtMs: 1712740800000,
          engagementState: "unread",
          visibilityState: "active",
          parent: { state: "none" },
          depth: 0,
          childCount: 2,
          isVisibleToHighlightedActor: true,
        },
        {
          messageId: "msg_000002",
          conversationId: "cnv_000001",
          parentMessageId: "msg_000001",
          sender: addresses.alice,
          subject: "Re: Need ack: replay panel copy update",
          bodyPreview: "Ack. I’ll land the wording change after lunch.",
          urgency: "normal",
          createdAtMs: 1712741400000,
          engagementState: "read",
          visibilityState: "active",
          parent: { state: "visible", messageId: "msg_000001", subject: "Need ack: replay panel copy update" },
          depth: 1,
          childCount: 0,
          isVisibleToHighlightedActor: true,
        },
        {
          messageId: "msg_000003",
          conversationId: "cnv_000001",
          parentMessageId: "msg_000001",
          sender: addresses.triageBot,
          subject: "Re: Need ack: replay panel copy update",
          bodyPreview: "I summarized the requested copy updates and attached the diff.",
          urgency: "normal",
          createdAtMs: 1712742000000,
          parent: { state: "visible", messageId: "msg_000001", subject: "Need ack: replay panel copy update" },
          depth: 1,
          childCount: 0,
          isVisibleToHighlightedActor: false,
        },
      ],
    },
    actions: {
      canReply: true,
      canReplyAll: true,
      canAck: true,
      canHide: true,
      canUnhide: false,
      canPeek: true,
    },
  },
  meta: baseMeta({ mode: "god", highlightAddressId: "adr_000001" }),
};

export const messageReaderSentFixture: BffSuccess<MessageReaderModel> = {
  ok: true,
  result: {
    messageId: "msg_000002",
    conversationId: "cnv_000001",
    viewKind: "sent",
    sender: addresses.alice,
    isVisibleToHighlightedActor: true,
    publicRecipients: [
      {
        ordinal: 0,
        role: "to",
        addressId: addresses.pmBot.addressId,
        address: addresses.pmBot.address,
        displayName: addresses.pmBot.displayName,
        kind: addresses.pmBot.kind,
        isVisibleToHighlightedActor: true,
      },
    ],
    subject: "Re: Need ack: replay panel copy update",
    body: {
      format: "plain",
      text: "Ack. I’ll land the wording change after lunch.",
    },
    urgency: "normal",
    createdAtMs: 1712741400000,
    references: [],
    parent: { state: "visible", messageId: "msg_000001", subject: "Need ack: replay panel copy update" },
    threadPreview: {
      mode: "chronological",
      nodes: [],
    },
    actions: {
      canReply: false,
      canReplyAll: false,
      canAck: false,
      canHide: false,
      canUnhide: false,
      canPeek: true,
    },
  },
  meta: baseMeta({ mode: "god", highlightAddressId: "adr_000001" }),
};
