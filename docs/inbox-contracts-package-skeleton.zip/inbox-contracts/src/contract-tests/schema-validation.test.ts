import { describe, expect, it } from "vitest";
import {
  AgentDirectoryResultSchema,
  AgentProfileModelSchema,
  CommandRunListResultSchema,
  ComposeDryRunResultSchema,
  ConversationInspectorModelSchema,
  DashboardSummaryModelSchema,
  InboxListResultSchema,
  MessageReaderModelSchema,
  SendMessageResultSchema,
  SessionModelSchema,
} from "../schemas";
import {
  agentDirectoryHappyFixture,
  agentProfileListFixture,
  commandRunsFixture,
  composeDryRunHappyFixture,
  composeDryRunZeroResolutionFixture,
  conversationInspectorFixture,
  dashboardSummaryFixture,
  inboxListEmptyFixture,
  inboxListHappyFixture,
  messageReaderHappyFixture,
  messageReaderSentFixture,
  sendMessageFixture,
  sessionFixture,
} from "../fixtures";

describe("contract fixtures", () => {
  it("parses session fixture", () => {
    expect(SessionModelSchema.parse(sessionFixture.result)).toBeTruthy();
  });

  it("parses inbox fixtures", () => {
    expect(InboxListResultSchema.parse(inboxListHappyFixture.result)).toBeTruthy();
    expect(InboxListResultSchema.parse(inboxListEmptyFixture.result)).toBeTruthy();
  });

  it("parses message reader fixtures", () => {
    expect(MessageReaderModelSchema.parse(messageReaderHappyFixture.result)).toBeTruthy();
    expect(MessageReaderModelSchema.parse(messageReaderSentFixture.result)).toBeTruthy();
  });

  it("parses agent and dashboard fixtures", () => {
    expect(AgentDirectoryResultSchema.parse(agentDirectoryHappyFixture.result)).toBeTruthy();
    expect(AgentProfileModelSchema.parse(agentProfileListFixture.result)).toBeTruthy();
    expect(DashboardSummaryModelSchema.parse(dashboardSummaryFixture.result)).toBeTruthy();
  });

  it("parses explorer and command-run fixtures", () => {
    expect(ConversationInspectorModelSchema.parse(conversationInspectorFixture.result)).toBeTruthy();
    expect(CommandRunListResultSchema.parse(commandRunsFixture.result)).toBeTruthy();
  });

  it("parses compose fixtures", () => {
    expect(ComposeDryRunResultSchema.parse(composeDryRunHappyFixture.result)).toBeTruthy();
    expect(ComposeDryRunResultSchema.parse(composeDryRunZeroResolutionFixture.result)).toBeTruthy();
    expect(SendMessageResultSchema.parse(sendMessageFixture.result)).toBeTruthy();
  });
});
