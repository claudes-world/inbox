import { z } from "zod";
import { ViewScopeSchema } from "../contexts";
import { AddressIdSchema } from "../ids";
import { EnvironmentRefSchema, TimestampMsSchema } from "../enums";

export const SessionModelSchema = z.object({
  env: EnvironmentRefSchema,
  dbPath: z.string(),
  defaultViewScope: ViewScopeSchema,
  defaultSendIdentity: AddressIdSchema.nullable(),
  resolvedActingAddressId: AddressIdSchema.nullable(),
  asOfMs: TimestampMsSchema.nullable(),
});
export type SessionModel = z.infer<typeof SessionModelSchema>;
