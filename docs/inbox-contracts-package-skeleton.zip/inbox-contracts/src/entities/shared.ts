import { z } from "zod";
import {
  AddressKindSchema,
  EffectiveRoleSchema,
  EngagementStateSchema,
  TimestampMsSchema,
  VisibilityStateSchema,
} from "../enums";
import { AddressIdSchema, MessageIdSchema } from "../ids";

export const AddressSummarySchema = z.object({
  addressId: AddressIdSchema,
  address: z.string().email(),
  displayName: z.string().nullable(),
  kind: AddressKindSchema,
  isActive: z.boolean(),
  isListed: z.boolean(),
  classification: z.string().nullable(),
});
export type AddressSummary = z.infer<typeof AddressSummarySchema>;

export const VisibilityAnnotationSchema = z.object({
  isVisibleToHighlightedActor: z.boolean().nullable().optional(),
});
export type VisibilityAnnotation = z.infer<typeof VisibilityAnnotationSchema>;

export const PublicRecipientDisplaySchema = VisibilityAnnotationSchema.extend({
  ordinal: z.number().int().nonnegative(),
  role: EffectiveRoleSchema,
  addressId: AddressIdSchema,
  address: z.string().email(),
  displayName: z.string().nullable(),
  kind: AddressKindSchema,
});
export type PublicRecipientDisplay = z.infer<typeof PublicRecipientDisplaySchema>;

export const DeliverySourceDisplaySchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("direct"),
    role: EffectiveRoleSchema,
  }),
  z.object({
    kind: z.literal("list"),
    role: EffectiveRoleSchema,
    listAddressId: AddressIdSchema,
    listAddress: z.string().email(),
  }),
]);
export type DeliverySourceDisplay = z.infer<typeof DeliverySourceDisplaySchema>;

export const DeliveryTimelineEventSchema = z.object({
  kind: z.enum(["delivered", "read", "ack", "hide", "unhide"]),
  atMs: TimestampMsSchema,
  actorAddressId: AddressIdSchema.nullish(),
});
export type DeliveryTimelineEvent = z.infer<typeof DeliveryTimelineEventSchema>;

export const ReferenceDisplaySchema = z.object({
  kind: z.string(),
  value: z.string(),
  label: z.string().nullable().optional(),
  mimeType: z.string().nullable().optional(),
});
export type ReferenceDisplay = z.infer<typeof ReferenceDisplaySchema>;

export const ParentLinkDisplaySchema = z.object({
  // Pure god-mode responses never produce "redacted".
  state: z.enum(["visible", "redacted", "none"]),
  messageId: MessageIdSchema.optional(),
  subject: z.string().optional(),
});
export type ParentLinkDisplay = z.infer<typeof ParentLinkDisplaySchema>;

export const ResolutionSummarySchema = z.object({
  logicalRecipientCount: z.number().int().nonnegative(),
  resolvedRecipientCount: z.number().int().nonnegative(),
  skippedInactiveMemberCount: z.number().int().nonnegative(),
  dedupedRecipientCount: z.number().int().nonnegative(),
});
export type ResolutionSummary = z.infer<typeof ResolutionSummarySchema>;

export const DryRunResolutionSummarySchema = ResolutionSummarySchema.extend({
  expandedCandidateCount: z.number().int().nonnegative(),
});
export type DryRunResolutionSummary = z.infer<typeof DryRunResolutionSummarySchema>;

export const VisibilityMatrixCellSchema = z.object({
  addressId: AddressIdSchema,
  delivery: z.object({
    engagement: EngagementStateSchema,
    visibility: VisibilityStateSchema,
  }).nullable(),
  isVisibleToHighlightedActor: z.boolean().nullable().optional(),
});
export type VisibilityMatrixCell = z.infer<typeof VisibilityMatrixCellSchema>;
